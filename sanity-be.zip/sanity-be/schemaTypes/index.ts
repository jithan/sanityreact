import blockContent from './blockContent'
import crewMember from './crewMember'
import castMember from './castMember'
import movie from './movie'
import person from './person'
import screening from './screening'
import plotSummary from './plotSummary'
import plotSummaries from './plotSummaries'
import article from './article'
import kalturaVideo from './kalturaVideo'
import pageBuilderType from './pageBuilderType'
import page from './page'

// Import blocks
import hero from './blocks/hero'
import features from './blocks/features'
import textSection from './blocks/textSection'
import splitImage from './blocks/splitImage'

export const schemaTypes = [
  // Document types
  movie,
  person,
  screening,
  article,
  page,

  // Page builder types
  pageBuilderType,

  // Block types
  hero,
  features,
  textSection,
  splitImage,

  // Other types
  blockContent,
  plotSummary,
  plotSummaries,
  castMember,
  crewMember,
  kalturaVideo,
]
